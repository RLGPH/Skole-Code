﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Regnetegn regnetegn;

        public MainWindow()
        {
            InitializeComponent();

        }

        enum Regnetegn
        {
            Plus,
            Minus,
            divider,
            Gange
        }
        int mGender = 0;
        int fGender = 0;
        private void btn_Plus_Click(object sender, RoutedEventArgs e)
        {
            regnetegn = Regnetegn.Plus;
            double resultat = regneFunktion(Regnetegn.Plus);
            tResultat.Text = resultat.ToString();
        }

        private void btn_minus_Click(object sender, RoutedEventArgs e)
        {
            regnetegn = Regnetegn.Minus;
            double resultat = regneFunktion(Regnetegn.Minus);
            tResultat.Text = resultat.ToString();
        }

        private void btn_divider_Click(object sender, RoutedEventArgs e)
        {
            regnetegn = Regnetegn.divider;
            double resultat = regneFunktion(Regnetegn.divider);
            tResultat.Text = resultat.ToString();
        }

        private void btn_gange_Click(object sender, RoutedEventArgs e)
        {
            regnetegn = Regnetegn.Gange;
            double resultat = regneFunktion(Regnetegn.Gange);
            tResultat.Text = resultat.ToString();
        }
        private void btn_Male_Loaded(object sender, RoutedEventArgs e)
        {
            mGender = 1;
            fGender = 0;
        }

        private void tb_Female_Loaded(object sender, RoutedEventArgs e)
        {
            fGender = 1;
            mGender = 0;
        }

        private void btn_BMI_Click(object sender, RoutedEventArgs e)
        {
            tResultat.Text = bmiresault.Tostring()   
            char B; 
        }

        private double regneFunktion(Regnetegn regnetegn)
        {
            double tal1 = 0;
            double tal2 = 0;
            double resultat = 0;
            try
            {
                tal1 = Convert.ToDouble(tb_tal1.Text);
                tal2 = Convert.ToDouble(tb_Tal2.Text);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "How! Der er opstået en fejl...");
            }
            if (regnetegn == Regnetegn.Plus)
            {
                resultat = tal1 + tal2;
            }
            else if (regnetegn == Regnetegn.Minus)
            {
                resultat = tal1 - tal2;
            }
            else if (regnetegn == Regnetegn.divider)
            {
                resultat = tal1 / tal2;
            }
            else if (regnetegn == Regnetegn.Gange)
            {
                resultat = tal1 * tal2;
            }
            return resultat;
        }

        private double BMICalculator(char B) 
        {
            double tal1 = 0;
            double tal2 = 0;
            double BMI = 0;
            try
            {
                tal1 = Convert.ToDouble(tb_tal1.Text);
                tal2 = Convert.ToDouble(tb_Tal2.Text);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "How! Der er opstået en fejl...");
            }
            BMI = tal2 * tal2 / tal1;
            if (fGender == 1)
            {

            }
            if (mGender == 1)
            {
                if (BMI >= 20)
                {
                    string bmiresault = "du er undervægtig din BMI er" + BMI;
                }
                else if (BMI <= 20 || BMI >= 25)
                {

                }
            }
            return bmiresault;
        }
    }
}
