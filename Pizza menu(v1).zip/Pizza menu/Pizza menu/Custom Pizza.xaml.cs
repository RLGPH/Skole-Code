﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pizza_menu
{
    /// <summary>
    /// Interaction logic for Custom_Pizza.xaml
    /// </summary>
    public partial class Custom_Pizza : Window
    {

        //used to get the pizza list and the selcted pizza
        public PizzaItem SelectedPizza { get; set; }
        public ObservableCollection<PizzaItem> SelectedPizzas { get; set; }
        //used to get the pizza list and the selcted pizza
        public ObservableCollection<SelectedTopping> SelectedToppings { get; set; }

        public ObservableCollection<CartItem> CartItems { get; set; }

        public Custom_Pizza(List<ToppingsItem> availableToppings, PizzaItem selectedPizza,ObservableCollection<CartItem> cartItems)
        {
            InitializeComponent();
            SelectedPizza = selectedPizza;
            SelectedToppings = new ObservableCollection<SelectedTopping>();
            CartItems = cartItems;

            SelectedPizzas = new ObservableCollection<PizzaItem>();
            if (SelectedPizza != null)
            {
                SelectedPizzas.Add(SelectedPizza);

                // Initialize the collection for selected toppings
                SelectedToppings = new ObservableCollection<SelectedTopping>();
            }
            SelectedToppings = new ObservableCollection<SelectedTopping>();


            dtg_Toppings.ItemsSource = availableToppings;
            tb_Selected_pizza.Text = selectedPizza.Name;
            dtg_PizzaWToppings.ItemsSource = SelectedToppings;
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            if (dtg_Toppings.SelectedItem is ToppingsItem selectedTopping)
            {
                // Check if the topping is already in the selected toppings collection
                var existingTopping = SelectedToppings.FirstOrDefault(t => t.Topping == selectedTopping);

                if (existingTopping != null)
                {
                    // If the topping exists, increment its quantity
                    existingTopping.Quantity++;

                    existingTopping.TotalPrice = existingTopping.Quantity * existingTopping.Topping.Price;
                }
                else
                {
                    var newTopping = new SelectedTopping
                    {
                        Topping = selectedTopping,
                        Quantity = 1,
                        TotalPrice = selectedTopping.Price
                    };
                    // If the topping does not exist, add it to the collection with a quantity of 1
                    SelectedToppings.Add(new SelectedTopping { Topping = selectedTopping, Quantity = 1 });
                }

                // Calculate the updated price by summing the prices of all selected toppings
                double updatedPrice = SelectedPizza.Price + SelectedToppings.Sum(t => t.Topping.Price * t.Quantity);

                // Update the TextBox with the updated price
                tb_price_custom.Text = updatedPrice.ToString("C2");
            }
            else
            {
            }
        }
        //go back without saveing
        private void btn_GoBack_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }


        //go back while saveing
        private void btn_Save_Click(object sender, RoutedEventArgs e)
        {
            double customPizzaPrice = (SelectedPizza.Price + SelectedToppings.Sum(t => t.Topping.Price * t.Quantity));
            SelectedPizza.Name = "Custom Pizza"; // Update with appropriate name
            SelectedPizza.Description = "Custom Pizza Description"; // Update with appropriate description
            SelectedPizza.Toppings = SelectedToppings.Select(t => t.Topping).ToList();

            var customPizzaCartItem = new CartItem(SelectedPizza.Id, SelectedPizza.Name, customPizzaPrice, "Custom Pizza");

            
            CartItems.Add(customPizzaCartItem);

            
            Close();
        }
    }
}