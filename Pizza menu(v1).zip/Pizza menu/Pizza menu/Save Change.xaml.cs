﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pizza_menu
{
    /// <summary>
    /// Interaction logic for Save_Change.xaml
    /// </summary>
    public partial class Save_Change : Window
    {
        public Save_Change()
        {
            InitializeComponent();
        }

        

        private void btn_No_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
