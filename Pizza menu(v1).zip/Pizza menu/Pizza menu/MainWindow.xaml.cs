﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Pizza_menu
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<DrinkItem> Drinks = new ObservableCollection<DrinkItem>();

        ObservableCollection<ExtraItem> Extra = new ObservableCollection<ExtraItem>();
        
        public ObservableCollection<CartItem> Cart = new ObservableCollection<CartItem>();

        public List<ToppingsItem> availableToppings = new List<ToppingsItem>();

        ObservableCollection<PizzaItem> Pizza = new ObservableCollection<PizzaItem>();
        
        public MainWindow()
        {
            InitializeComponent();
            availableToppings.Add(new ToppingsItem(0, "", 0));

            Pizza.Add(new PizzaItem(0, "Cheese pizza", 20, "cheese on bread and souce" ,availableToppings[0]));
            Pizza.Add(new PizzaItem(2, "Pepperoni", 12.99, "Spicy pepperoni and mozzarella", availableToppings[0]));
            Pizza.Add(new PizzaItem(3, "Vegetarian", 11.99, "Assorted veggies and mozzarella", availableToppings[0]));
            Pizza.Add(new PizzaItem(4, "Hawaiian", 13.99, "Ham, pineapple, and mozzarella", availableToppings[0]));
            Pizza.Add(new PizzaItem(5, "Meat Lover's", 14.99, "Pepperoni, sausage, and bacon", availableToppings[0]));
            Pizza.Add(new PizzaItem(6, "BBQ Chicken", 13.99, "Grilled chicken and BBQ sauce", availableToppings[0]));
            Pizza.Add(new PizzaItem(7, "Mushroom Supreme", 12.99, "Mushrooms, olives, and mozzarella", availableToppings[0]));
            Pizza.Add(new PizzaItem(8, "Four Cheese", 11.99, "Mozzarella, cheddar, provolone, and feta", availableToppings[0]));
            Pizza.Add(new PizzaItem(9, "Spinach and Feta", 12.99, "Fresh spinach and creamy feta", availableToppings[0]));
            Pizza.Add(new PizzaItem(10, "Supreme Deluxe", 14.99, "Pepperoni, sausage, peppers, and onions", availableToppings[0]));

            availableToppings.Add(new ToppingsItem(1, "Mushrooms", 1.49));

            Drinks.Add(new DrinkItem(0, "Water", 10));
            Drinks.Add(new DrinkItem(1, "bepsi", 14.99));
            Drinks.Add(new DrinkItem(2, "Cola 0.001L", 999.99));

            Extra.Add(new ExtraItem(0, "Bread sticks", 10));
            Extra.Add(new ExtraItem(1, "Fries Small", 15));
            Extra.Add(new ExtraItem(2, "Fries big", 20));

            dtg_Menu.ItemsSource = Drinks;
            dtg_BuyingList_Buy.ItemsSource = Cart;

        }
        //combobox used to select which list should shown in the menu list
        private void cmb_Menu_Selection_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           ComboBoxItem? selectedCategory = cmb_Menu_Selection.SelectedItem as ComboBoxItem; 

#pragma warning disable CS8602 // Dereference of a possibly null reference.
            if (selectedCategory.Content.ToString() == "Drinks")
            {
                //used to call the list to the datagrid
                dtg_Menu.ItemsSource = Drinks;
            }
            else if (selectedCategory.Content.ToString() == "Extra")
            {
                dtg_Menu.ItemsSource = Extra;
            }
            else if (selectedCategory.Content.ToString() == "Pizza")
            {
                dtg_Menu.ItemsSource = Pizza;
            }
#pragma warning restore CS8602 // Dereference of a possibly null reference.

        }
        //takes you in to the buy menu
        private void btn_Menu_Buy_Click(object sender, RoutedEventArgs e)
        {
            //basicly this takes the total price for it self out of the list
            double totalPrice = Cart.Sum(item => item.Price);

            //this transfers the list and the price to the checkout window and opens the window
            Checkout checkout = new Checkout(Cart, totalPrice);
            checkout.ShowDialog();

            //recalculates the totalprice after the checkout window close
            CalculateTotalPrice();
        }

        private void btn_ADD_to_order_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = dtg_Menu.SelectedItem;
            
            if (selectedItem is DrinkItem drink)
            {    
                var cartItem = new CartItem(drink.Id, drink.Name, drink.Price, "Drink");
                Cart.Add(cartItem);
            }
            else if (selectedItem is ExtraItem extra)
            {    
                var cartItem = new CartItem(extra.Id, extra.Name, extra.Price, "Extra");
                Cart.Add(cartItem);
            }
            else if (selectedItem is PizzaItem pizza)
            {      
                var cartItem = new CartItem(pizza.Id, pizza.Name, pizza.Price, "Pizza");
                Cart.Add(cartItem);
            }
            CalculateTotalPrice(); 
        }
        private void CalculateTotalPrice()
        {
            TotalPrice = Cart.Sum(item => item.Price);
        }
        
        private void btn_Remove_From_Order_Click(object sender, RoutedEventArgs e)
        {
            if (dtg_BuyingList_Buy.SelectedItem is CartItem selectedItem)
            {
                //used to remove and recalculate the price of everything in the totalprice price taken from Cartitem 
                Cart.Remove(selectedItem);
                CalculateTotalPrice();
            }
        }
        private double totalPrice;
        public double TotalPrice
        {
            get { return totalPrice; }
            set
            {
                //sets totalprice as a value
                totalPrice = value;

                //shows what ´the total price is and what currency its in C2 is a way to format numbers in to a currency
                tb_Price.Text = totalPrice.ToString("C2");
            }
        }

        //give the selected data from a data grid to CustomPizza window and the toppings list
        private void btn_Custom_Click(object sender, RoutedEventArgs e)
        {

            if (dtg_Menu.SelectedItem is PizzaItem selectedPizza)
            {
                //transfer data from main window to custom pizza window and opens it
                Custom_Pizza customPizzaWindow = new Custom_Pizza(availableToppings, selectedPizza, Cart);
                customPizzaWindow.ShowDialog();
            }
        }
    }
    
    public class DrinkItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public DrinkItem(int Id, string Name, double Price)
        {
            this.Id = Id;
            this.Name = Name;
            this.Price = Price;
        }
    }

    public class ExtraItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public ExtraItem(int Id, string Name, double Price)
        {
            this.Id = Id;
            this.Name = Name;
            this.Price = Price;
        }
    }
    public class ToppingsItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public ToppingsItem(int Id, string Name, double Price)
        {
            this.Id = Id;
            this.Name = Name;
            this.Price = Price;
        }
    }

    public class PizzaItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public string Description { get; set; }
        public List<ToppingsItem> Toppings { get; set; }
        public PizzaItem(int Id, string Name, double Price, string description, ToppingsItem toppingsItem)
        {
            this.Id = Id;
            this.Name = Name;
            this.Price = Price;
            Description = description;
            Toppings = new List<ToppingsItem>();
        }
    }
    public class CartItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public string Description { get; set; }

        public CartItem(int Id, string Name, double Price, string description)
        {
            this.Id = Id;
            this.Name = Name;
            this.Price = Price;
            this.Description = description;
        }
    }
    public class SelectedTopping
    {
        public ToppingsItem Topping { get; set; }
    public int Quantity { get; set; }
    public double TotalPrice { get; set; }
    }
}