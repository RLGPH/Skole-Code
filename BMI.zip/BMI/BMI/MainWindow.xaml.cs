﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BMI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int selectedGenderValue = 0; // Default value for an unknown selection

        public MainWindow()
        {
            InitializeComponent();

            
            cb_Kønd.SelectionChanged += Cb_Kønd_SelectionChanged;
        }

        private void Cb_Kønd_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            ComboBoxItem selectedItem = cb_Kønd.SelectedItem as ComboBoxItem;

            if (selectedItem != null && selectedItem.Tag is string tagValue)
            {
                if (int.TryParse(tagValue, out int value))
                {
                    selectedGenderValue = value; // Store the selected value
                }
            }
        }

        public void btn_beregn_Click(object sender, RoutedEventArgs e)
        {
            string højdeText = Højde.Text; 
            string vægtText = vægt.Text; 

            if (double.TryParse(højdeText, out double højdeValue) && double.TryParse(vægtText, out double vægtValue))
            {

                double bmi = vægtValue / (højdeValue * højdeValue); 
                if (selectedGenderValue == 1)
                {
                    if (bmi < 20)
                    {
                        MessageBox.Show($"BMI: {bmi:F2}\ndu er undervægtige.");
                    }
                    else if (bmi < 25)
                    {
                        MessageBox.Show($"BMI: {bmi:F2}\ndu er normalvægtige.");
                    }
                    else if (bmi < 30)
                    {
                        MessageBox.Show($"BMI: {bmi:F2}\ndu er overvægtige.");
                    }
                    else
                    {
                        MessageBox.Show($"BMI: {bmi:F2}\ndu er stærkt overvægtige.");
                    }
                }
                if (selectedGenderValue == 2)
                {
                    if (bmi < 18.6)
                    {
                        MessageBox.Show($"BMI: {bmi:F2}\ndu er undervægtige.");
                    }
                    else if (bmi < 23.8)
                    {
                        MessageBox.Show($"BMI: {bmi:F2}\ndu er normalvægtige.");
                    }
                    else if (bmi < 28.6)
                    {
                        MessageBox.Show($"BMI: {bmi:F2}\ndu er overvægtige.");
                    }
                    else
                    {
                        MessageBox.Show($"BMI: {bmi:F2}\ndu er stærkt overvægtige.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter valid numbers for Højde and vægt.");
            }
        }
    }
}
