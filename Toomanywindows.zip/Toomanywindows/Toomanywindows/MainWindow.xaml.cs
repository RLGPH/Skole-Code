﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Toomanywindows
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void btn_Window1_Click(object sender, RoutedEventArgs e)
        {
            vindue2 navn = new vindue2();
            navn.fornavn = textBox1.Text;
            navn.efternavn = textBox2.Text;
            navn.Alder = alder.Text;
            navn.ShowDialog();

            textBox1.Text = navn.fornavn;
            textBox2.Text = navn.efternavn;
            alder.Text = navn.Alder;

            if(navn.DialogResult == true)
            {
                textBox1.Text = navn.fornavn;
                textBox2.Text = navn.efternavn;
                alder.Text = navn.Alder;
            }
            

        }
    }
}
