﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Toomanywindows
{
    /// <summary>
    /// Interaction logic for vindue2.xaml
    /// </summary>
    public partial class vindue2 : Window
    {
        public string fornavn
        {
            get
            {
                return textBox1.Text;
            }
            set
            {
                textBox1.Text = value;
            }
        }
        public string efternavn
        {
            get
            {
                return textbox2.Text;
            }
            set
            {
                textbox2.Text = value;
            }
        }

        public string Alder
        {
            get
            {
                return alder.Text;
            }
            set
            {
                alder.Text = value;
            }
        }
        public vindue2()
        {
            InitializeComponent();

        }

        private void btn_Fortryd_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            this.Close();
        }

        private void DuDøbes_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            this.Close();
        }

    }
}
